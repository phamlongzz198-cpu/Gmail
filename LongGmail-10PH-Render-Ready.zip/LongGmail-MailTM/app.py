import os
import re
import secrets
import string
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
import json

from flask import Flask, jsonify, render_template, request, session

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", secrets.token_hex(32))
MAIL_API = "https://api.mail.tm"
UA = "LongGmail10ph/1.0 (personal client; see https://mail.tm)"


def provider_request(path, method="GET", payload=None, token=None):
    body = None if payload is None else json.dumps(payload).encode("utf-8")
    headers = {"Accept": "application/ld+json, application/json", "User-Agent": UA}
    if body is not None:
        headers["Content-Type"] = "application/json"
    if token:
        headers["Authorization"] = "Bearer " + token
    req = Request(MAIL_API + path, data=body, headers=headers, method=method)
    try:
        with urlopen(req, timeout=20) as response:
            raw = response.read().decode("utf-8", "replace")
            return json.loads(raw) if raw else {}
    except HTTPError as e:
        detail = e.read().decode("utf-8", "replace")
        try:
            parsed = json.loads(detail)
            detail = parsed.get("detail") or parsed.get("message") or detail
        except Exception:
            pass
        raise RuntimeError(f"Mail.tm trả lỗi HTTP {e.code}: {str(detail)[:220]}")
    except (URLError, TimeoutError, json.JSONDecodeError) as e:
        raise RuntimeError("Không kết nối được Mail.tm: " + str(e))


def token_required():
    token = session.get("mail_token")
    if not token:
        raise RuntimeError("Chưa có hộp thư. Bấm “Tạo email mới” trước.")
    return token


def get_domains():
    data = provider_request("/domains")
    domains = data.get("hydra:member", [])
    active = [d.get("domain") for d in domains if d.get("isActive", True) and d.get("domain")]
    if not active:
        raise RuntimeError("Mail.tm hiện không trả về domain khả dụng.")
    return active


def random_local():
    return "long" + "".join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(10))


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/api/new")
def new_inbox():
    try:
        domains = get_domains()
        last_error = None
        for _ in range(5):
            address = random_local() + "@" + secrets.choice(domains)
            password = secrets.token_urlsafe(18)
            try:
                account = provider_request("/accounts", "POST", {"address": address, "password": password})
                auth = provider_request("/token", "POST", {"address": address, "password": password})
                token = auth.get("token")
                if not token:
                    raise RuntimeError("Mail.tm không trả về token hộp thư.")
                session["mail_token"] = token
                session["mail_address"] = account.get("address", address)
                session["mail_account_id"] = account.get("id")
                session["mail_password"] = password
                return jsonify({"email": session["mail_address"], "expiresIn": 600})
            except RuntimeError as e:
                last_error = str(e)
                if "already" not in last_error.lower() and "exist" not in last_error.lower():
                    raise
        raise RuntimeError(last_error or "Không tạo được địa chỉ email. Thử lại.")
    except Exception as e:
        return jsonify({"error": str(e)}), 502


@app.get("/api/messages")
def messages():
    try:
        token = token_required()
        listing = provider_request("/messages?page=1", token=token)
        items = listing.get("hydra:member", [])
        out = []
        for item in items[:30]:
            mid = item.get("id")
            if not mid:
                continue
            try:
                full = provider_request("/messages/" + mid, token=token)
            except RuntimeError:
                full = item
            text_body = full.get("text") or item.get("intro") or ""
            html_body = full.get("html") or ""
            if isinstance(html_body, list):
                html_body = "\n".join(str(x) for x in html_body)
            content = text_body + "\n" + str(html_body)
            match = re.search(r"(?i)(?:verification|verify|confirmation|security|auth|otp|code|código|mã xác minh|mã xác nhận|mã bảo mật)[^\d]{0,45}(\d{4,8})", content)
            if not match:
                match = re.search(r"\b(\d{6})\b", content)
            if not match:
                match = re.search(r"\b(\d{4,8})\b", content)
            sender = item.get("from") or {}
            if isinstance(sender, dict):
                sender = sender.get("address") or sender.get("name") or "Không rõ"
            out.append({
                "id": mid,
                "subject": full.get("subject") or item.get("subject") or "(Không có tiêu đề)",
                "from": sender,
                "date": full.get("createdAt") or item.get("createdAt") or "",
                "intro": item.get("intro") or "",
                "text": text_body,
                "code": match.group(1) if match else ""
            })
        return jsonify({"email": session.get("mail_address"), "messages": out, "total": listing.get("hydra:totalItems", len(out))})
    except Exception as e:
        return jsonify({"error": str(e)}), 502


@app.post("/api/clear")
def clear_inbox():
    session.pop("mail_token", None)
    session.pop("mail_address", None)
    session.pop("mail_account_id", None)
    session.pop("mail_password", None)
    return jsonify({"ok": True})


@app.get("/health")
def health():
    return jsonify({"ok": True})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False)

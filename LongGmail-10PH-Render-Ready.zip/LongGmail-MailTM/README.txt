# LONG GMAIL 10PH — Mail.tm edition

Giữ giao diện kiểu LONG GMAIL 10PH, đổi sang Mail.tm API để tạo hộp thư, tự tải thư và dò mã OTP. Không cần API key của Mail.tm; mỗi hộp thư có token nội bộ lưu trong session máy chủ.

## Chạy trên máy tính
1. Cài Python 3.10+.
2. Mở terminal trong thư mục này:
   ```bash
   pip install -r requirements.txt
   python app.py
   ```
3. Mở `http://127.0.0.1:5000`.

## Chạy trên Android
Dùng Termux hoặc môi trường Python có thể cài Flask:
```bash
pip install -r requirements.txt
python app.py
```
Sau đó mở `http://127.0.0.1:5000` trên cùng điện thoại. Chỉ mở file HTML riêng lẻ sẽ không chạy backend.

## Deploy Render
- Tạo Web Service từ repository có các file này.
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`
- Có thể đặt biến môi trường `FLASK_SECRET_KEY` thành một chuỗi ngẫu nhiên riêng.

## Ghi chú
- API dựa trên tài liệu chính thức Mail.tm: https://docs.mail.tm/
- Tạo email và đọc thư cần backend chạy; đây không phải Gmail thật.
- Bộ đếm 10 phút chỉ là giao diện, không đảm bảo nhà cung cấp xóa hộp thư sau đúng 10 phút.
- Không dùng email tạm cho tài khoản quan trọng hoặc để nhận thông tin nhạy cảm.
- Mail.tm có điều khoản sử dụng và giới hạn tốc độ; hãy đọc tài liệu chính thức trước khi triển khai công khai. Có liên kết attribution tới Mail.tm trong giao diện.


## Public deployment checklist
- Push `app.py`, `templates/index.html`, `requirements.txt`, `render.yaml`, and this README to a GitHub repository.
- In Render choose New > Blueprint (or Web Service), connect the repository, and deploy.
- Keep the generated `FLASK_SECRET_KEY` private. Do not publish mailbox tokens/passwords.
- Important: Mail.tm's published terms prohibit proxying/mirroring its API under another domain and require attribution. Review the current terms before exposing this as a public multi-user service. The current backend calls Mail.tm server-side; if the terms prohibit this use case, do not deploy it publicly without permission. For public use, choose a provider whose terms explicitly allow third-party hosted applications.
